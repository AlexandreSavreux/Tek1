/*
** EPITECH PROJECT, 2022
** CPE_corewar_2017
** File description:
** Created by tiflo,
*/
#include "my.h"

int main(int ac, char **av)
{
	return (0);
}