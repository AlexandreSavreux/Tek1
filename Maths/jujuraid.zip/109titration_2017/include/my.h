/*
** EPITECH PROJECT, 2018
** my.h
** File description:
** header of 109titration
*/
void sort_number(char ***x, char ***y, int n);

void put_in_board(char **tab, char ***board_x, char ***board_y, int i);

void do_the_programe(char ***board_x, char ***board_y, int i, char ***y_s);

int error(int fd);

void malloc_tab(char ***board, int n);
