/*
** EPITECH PROJECT, 2018
** error.c
** File description:
** check the file
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <zconf.h>
#include "my.h"

int error(int fd)
{


}
